import os
from flask import Flask, render_template, request, redirect, url_for
from flask_wtf import FlaskForm
from flask_bootstrap import Bootstrap
from werkzeug.utils import secure_filename
from wtforms import FileField, SubmitField
from wtforms.validators import DataRequired
from PyPDF2 import PdfReader
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from collections import Counter

app = Flask(__name__)
app.config["SECRET_KEY"] = "your-secret-key"
bootstrap = Bootstrap(app)

# Download the 'punkt' resource (if not already downloaded)
nltk.download("punkt")

# Set of common English stopwords
stop_words = set(stopwords.words("english"))


class UploadForm(FlaskForm):
    pdf_file = FileField("Upload Resume (PDF)", validators=[DataRequired()])
    submit = SubmitField("Submit")


def extract_text_from_pdf(pdf_file):
    pdf_reader = PdfReader(pdf_file)
    text = ""
    for page in pdf_reader.pages:
        text += page.extract_text()
    return text


def extract_keywords(text, top_n=5):
    # Tokenize the text into words
    words = word_tokenize(text)

    # Filter out stopwords and punctuation
    filtered_words = [
        word.lower()
        for word in words
        if word.lower() not in stop_words and word.isalpha()
    ]

    # Get word frequencies
    word_freq = Counter(filtered_words)

    # Get the top_n most common keywords
    keywords = word_freq.most_common(top_n)

    return keywords


@app.route("/", methods=["GET", "POST"])
def upload_resume():
    form = UploadForm()
    if form.validate_on_submit():
        pdf_file = form.pdf_file.data
        filename = secure_filename(pdf_file.filename)
        upload_folder = os.path.join(app.root_path, "uploads")
        os.makedirs(upload_folder, exist_ok=True)
        pdf_path = os.path.join(upload_folder, filename)
        pdf_file.save(pdf_path)
        return redirect(url_for("display_skills", filename=filename))
    return render_template("upload_resume.html", form=form)


@app.route("/skills/<filename>")
def display_skills(filename):
    upload_folder = os.path.join(app.root_path, "uploads")
    pdf_path = os.path.join(upload_folder, filename)

    with open(pdf_path, "rb") as file:
        pdf_text = extract_text_from_pdf(file)
        skill_keywords = extract_keywords(pdf_text)

    return render_template(
        "display_skills.html", pdf_text=pdf_text, skill_keywords=skill_keywords
    )


if __name__ == "__main__":
    app.run(debug=True)
